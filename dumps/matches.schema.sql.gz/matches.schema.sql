-- phpMyAdmin SQL Dump
-- version 4.9.5deb2
-- https://www.phpmyadmin.net/
--
-- Хост: localhost:3306
-- Время создания: Июн 19 2020 г., 16:58
-- Версия сервера: 5.7.30-0ubuntu0.18.04.1
-- Версия PHP: 7.1.33-16+ubuntu18.04.1+deb.sury.org+1

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- База данных: `matches`
--

-- --------------------------------------------------------

--
-- Структура таблицы `bets`
--

CREATE TABLE `bets` (
  `id` int(11) NOT NULL,
  `match_id` int(11) DEFAULT NULL COMMENT 'Матч',
  `bet` json DEFAULT NULL COMMENT 'Ставка',
  `created_at` int(11) DEFAULT NULL COMMENT 'Дата создания',
  `updated_at` int(11) DEFAULT NULL COMMENT 'Дата обновления'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Структура таблицы `config`
--

CREATE TABLE `config` (
  `id` int(11) NOT NULL,
  `param` varchar(255) NOT NULL,
  `value` varchar(255) NOT NULL,
  `title` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Структура таблицы `matches`
--

CREATE TABLE `matches` (
  `id` int(11) NOT NULL,
  `sport_type_id` int(11) DEFAULT NULL COMMENT 'Вид спорта',
  `tournament_id` int(11) DEFAULT NULL COMMENT 'Турнир',
  `parent_match_id` varchar(32) DEFAULT NULL COMMENT 'Родительский матч',
  `external_match_id` varchar(32) DEFAULT NULL COMMENT 'Внешний ID матча',
  `team_home_id` int(11) DEFAULT NULL COMMENT 'Хозяева',
  `team_guest_id` int(11) DEFAULT NULL COMMENT 'Гости',
  `start` int(11) DEFAULT NULL COMMENT 'Дата начала матча',
  `is_bet` smallint(1) DEFAULT '0' COMMENT 'Флаг наличия ставок',
  `created_at` int(11) DEFAULT NULL COMMENT 'Дата создания',
  `updated_at` int(11) DEFAULT NULL COMMENT 'Дата обновления'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Структура таблицы `migration`
--

CREATE TABLE `migration` (
  `version` varchar(180) NOT NULL,
  `apply_time` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Структура таблицы `sport_types`
--

CREATE TABLE `sport_types` (
  `id` int(11) NOT NULL,
  `title` varchar(255) NOT NULL COMMENT 'Название',
  `is_active` smallint(1) DEFAULT '1' COMMENT 'Статус',
  `created_at` int(11) DEFAULT NULL COMMENT 'Дата создания',
  `updated_at` int(11) DEFAULT NULL COMMENT 'Дата обновления'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Структура таблицы `teams`
--

CREATE TABLE `teams` (
  `id` int(11) NOT NULL,
  `sport_type_id` int(11) DEFAULT NULL COMMENT 'Вид спорта',
  `title` varchar(255) NOT NULL COMMENT 'Название',
  `is_active` smallint(1) DEFAULT '1' COMMENT 'Статус',
  `created_at` int(11) DEFAULT NULL COMMENT 'Дата создания',
  `updated_at` int(11) DEFAULT NULL COMMENT 'Дата обновления'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Структура таблицы `tournaments`
--

CREATE TABLE `tournaments` (
  `id` int(11) NOT NULL,
  `title` varchar(255) NOT NULL COMMENT 'Название',
  `is_active` smallint(1) DEFAULT '1' COMMENT 'Статус',
  `created_at` int(11) DEFAULT NULL COMMENT 'Дата создания',
  `updated_at` int(11) DEFAULT NULL COMMENT 'Дата обновления'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Структура таблицы `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `username` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `role` varchar(255) NOT NULL DEFAULT 'user',
  `is_active` smallint(1) DEFAULT '1',
  `created_at` int(11) DEFAULT NULL COMMENT 'Ð”Ð°Ñ‚Ð° ÑÐ¾Ð·Ð´Ð°Ð½Ð¸Ñ',
  `updated_at` int(11) DEFAULT NULL COMMENT 'Ð”Ð°Ñ‚Ð° Ð¾Ð±Ð½Ð¾Ð²Ð»ÐµÐ½Ð¸Ñ'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Индексы сохранённых таблиц
--

--
-- Индексы таблицы `bets`
--
ALTER TABLE `bets`
  ADD PRIMARY KEY (`id`),
  ADD KEY `match_id_index` (`match_id`);

--
-- Индексы таблицы `config`
--
ALTER TABLE `config`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `matches`
--
ALTER TABLE `matches`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `external_match_id_index` (`external_match_id`),
  ADD KEY `sport_type_id_index` (`sport_type_id`),
  ADD KEY `parent_match_id_index` (`parent_match_id`),
  ADD KEY `team_home_id_index` (`team_home_id`),
  ADD KEY `team_guest_id_index` (`team_guest_id`),
  ADD KEY `is_bet_index` (`is_bet`),
  ADD KEY `tournament_id_index` (`tournament_id`);

--
-- Индексы таблицы `migration`
--
ALTER TABLE `migration`
  ADD PRIMARY KEY (`version`);

--
-- Индексы таблицы `sport_types`
--
ALTER TABLE `sport_types`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `title_index` (`title`),
  ADD KEY `is_active_index` (`is_active`);

--
-- Индексы таблицы `teams`
--
ALTER TABLE `teams`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `sport_type_id_title_index` (`sport_type_id`,`title`),
  ADD KEY `sport_type_id_index` (`sport_type_id`),
  ADD KEY `is_active_index` (`is_active`),
  ADD KEY `title_index` (`title`) USING BTREE;

--
-- Индексы таблицы `tournaments`
--
ALTER TABLE `tournaments`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `title_index` (`title`),
  ADD KEY `is_active_index` (`is_active`);

--
-- Индексы таблицы `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD KEY `username_index` (`username`),
  ADD KEY `is_active_index` (`is_active`);

--
-- AUTO_INCREMENT для сохранённых таблиц
--

--
-- AUTO_INCREMENT для таблицы `bets`
--
ALTER TABLE `bets`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT для таблицы `config`
--
ALTER TABLE `config`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT для таблицы `matches`
--
ALTER TABLE `matches`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT для таблицы `sport_types`
--
ALTER TABLE `sport_types`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT для таблицы `teams`
--
ALTER TABLE `teams`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT для таблицы `tournaments`
--
ALTER TABLE `tournaments`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT для таблицы `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- Ограничения внешнего ключа сохраненных таблиц
--

--
-- Ограничения внешнего ключа таблицы `bets`
--
ALTER TABLE `bets`
  ADD CONSTRAINT `bets_matches_fk` FOREIGN KEY (`match_id`) REFERENCES `matches` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Ограничения внешнего ключа таблицы `matches`
--
ALTER TABLE `matches`
  ADD CONSTRAINT `matches_sport_types_fk` FOREIGN KEY (`sport_type_id`) REFERENCES `sport_types` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `matches_team_guest_fk` FOREIGN KEY (`team_guest_id`) REFERENCES `teams` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `matches_team_home_fk` FOREIGN KEY (`team_home_id`) REFERENCES `teams` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `matches_tournament_fk` FOREIGN KEY (`tournament_id`) REFERENCES `tournaments` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Ограничения внешнего ключа таблицы `teams`
--
ALTER TABLE `teams`
  ADD CONSTRAINT `teams_sport_types_fk` FOREIGN KEY (`sport_type_id`) REFERENCES `sport_types` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
